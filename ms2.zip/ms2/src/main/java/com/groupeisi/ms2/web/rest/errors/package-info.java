/**
 * Rest layer error handling.
 */
package com.groupeisi.ms2.web.rest.errors;
