/**
 * Application configuration.
 */
package com.groupeisi.ms2.config;
