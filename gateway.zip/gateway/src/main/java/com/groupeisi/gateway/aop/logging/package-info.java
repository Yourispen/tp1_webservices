/**
 * Logging aspect.
 */
package com.groupeisi.gateway.aop.logging;
