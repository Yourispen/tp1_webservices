/**
 * Domain objects.
 */
package com.groupeisi.gateway.domain;
