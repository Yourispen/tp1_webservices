/**
 * Application configuration.
 */
package com.groupeisi.gateway.config;
