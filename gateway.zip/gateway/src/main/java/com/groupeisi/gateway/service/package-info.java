/**
 * Service layer.
 */
package com.groupeisi.gateway.service;
