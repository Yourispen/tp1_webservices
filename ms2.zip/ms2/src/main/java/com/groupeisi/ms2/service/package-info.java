/**
 * Service layer.
 */
package com.groupeisi.ms2.service;
