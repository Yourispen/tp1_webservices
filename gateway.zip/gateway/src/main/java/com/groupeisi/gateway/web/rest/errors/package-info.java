/**
 * Rest layer error handling.
 */
package com.groupeisi.gateway.web.rest.errors;
