/**
 * Logging aspect.
 */
package com.groupeisi.ms2.aop.logging;
