/**
 * Rest layer.
 */
package com.groupeisi.gateway.web.rest;
