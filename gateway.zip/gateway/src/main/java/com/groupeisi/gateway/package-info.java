/**
 * Application root.
 */
package com.groupeisi.gateway;
