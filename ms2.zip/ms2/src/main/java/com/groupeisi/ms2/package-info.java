/**
 * Application root.
 */
package com.groupeisi.ms2;
