/**
 * Application security utilities.
 */
package com.groupeisi.ms2.security;
