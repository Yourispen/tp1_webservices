/**
 * Rest layer visual models.
 */
package com.groupeisi.gateway.web.rest.vm;
