/**
 * Domain objects.
 */
package com.groupeisi.ms2.domain;
