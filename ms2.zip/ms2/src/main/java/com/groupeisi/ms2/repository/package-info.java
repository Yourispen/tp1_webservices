/**
 * Repository layer.
 */
package com.groupeisi.ms2.repository;
