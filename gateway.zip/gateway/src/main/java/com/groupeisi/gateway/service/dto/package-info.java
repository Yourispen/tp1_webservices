/**
 * Data transfer objects for rest mapping.
 */
package com.groupeisi.gateway.service.dto;
