/**
 * Webflux database column mapper.
 */
package com.groupeisi.gateway.repository.rowmapper;
