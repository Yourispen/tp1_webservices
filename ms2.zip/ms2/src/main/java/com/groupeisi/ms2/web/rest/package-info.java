/**
 * Rest layer.
 */
package com.groupeisi.ms2.web.rest;
